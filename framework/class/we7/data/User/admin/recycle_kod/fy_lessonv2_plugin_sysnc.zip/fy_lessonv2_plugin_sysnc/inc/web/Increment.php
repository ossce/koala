<?php
 header("\114\x6f\x63\x61\164\151\157\x6e\72" . $this->createWebUrl("\143\x61\164\145\x67\x6f\162\x79"));