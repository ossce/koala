<?php

$id = intval($_GPC['id']);
$vip_member = pdo_get($this->table_member_vip, array('uniacid'=>$uniacid,'id'=>$id));
if(empty($vip_member)){
	message("该条记录不存在");
}

$vip_level = pdo_get($this->table_vip_level, array('uniacid'=>$uniacid,'id'=>$vip_member['level_id']));
if(!empty($vip_level)){
	message("该VIP等级存在，禁止删除该VIP等级的会员");
}

if(pdo_delete($this->table_member_vip, array('uniacid'=>$uniacid,'id'=>$id))){

	$refurl = $_GPC['refurl'] ? './index.php?'.base64_decode($_GPC['refurl']) : $this->createWebUrl('viporder', array('op'=>'vipMember'));
	message("删除成功", $refurl, "success");
}else{
	message("删除时报，请稍后重试", "", "error");
}