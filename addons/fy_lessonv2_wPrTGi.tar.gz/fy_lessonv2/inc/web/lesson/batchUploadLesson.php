<?php

set_time_limit(0);
load()->func('logging');

if($_FILES['lessonFile']['error'] != '0'){
	message("系统繁忙，上传文件失败，请稍后重试", $this->createWebUrl("lesson"), "error");
}

$filename = $_FILES['lessonFile']['name'];
$tmp_file = $_FILES['lessonFile']['tmp_name'];

header("Content-type:text/html;charset=utf-8");

//文件后缀名
$suffix = strtolower(substr(strrchr($filename, '.'), 1));
if($suffix != "xls") {
	message("请上传后缀是xls的文件", $this->createWebUrl("lesson"), "error");
}

//设置图片上传目录
$image_dirpath = ATTACHMENT_ROOT."images/";
$this->checkdir($image_dirpath);
$image_dirpath .= "{$uniacid}/";
$this->checkdir($image_dirpath);
$image_dirpath .= date('Y', time())."/";
$this->checkdir($image_dirpath);
$image_dirpath .= date('m', time())."/";
$this->checkdir($image_dirpath);

//设置excel文件临时存储目录
$savePath = ATTACHMENT_ROOT.'excel/';
if (!file_exists($savePath)) {
	mkdir($savePath, 0777);
}
$savePath .= 'fy_lessonv2/';
if (!file_exists($savePath)) {
	mkdir($savePath, 0777);
}
$savePath .= $uniacid . '/';
if (!file_exists($savePath)) {
	mkdir($savePath, 0777);
}

/* 命名临时上传的文件 */
$newfile = $savePath . 'LESSON_' . random(24) . "." . $suffix;

/* 开始上传 */
if (!copy($tmp_file, $newfile)) {
	message("上传文件失败，请稍候重试", $this->createWebUrl("lesson"), "error");
}

$phpexcel = new FyLessonv2PHPExcel();
$data = $phpexcel->inputExcel($newfile);
if (file_exists($newfile)) {
	unlink($newfile);
}

$i=0;
foreach($data as $k=>$v){
	$serial = $k+1;

	/* 过滤第一行说明和第二行名称 */
	if($k < 3){
		continue;
	}

	if(!trim($v[1])){
		logging_run('课程'.$serial.'导入失败，原因：课程名称为空', 'trace', 'fy_lessonv2_'.$uniacid.date('Y-m-d'));
		continue;
	}
	if(!trim($v[4])){
		logging_run('课程'.$serial.'导入失败，原因：课程封面图为空', 'trace', 'fy_lessonv2_'.$uniacid.date('Y-m-d'));
		continue;
	}

	$category = explode('/', $v[2]);
	
	if($v[4]){
		$images = random(30).'.';
		$image_type = $site_common->saveImage($v[4], $image_dirpath.$images, $type = '');
		if(!$image_type){
			logging_run('课程'.$serial.'封面图导入失败，原因：远程图片保存失败', 'trace', 'fy_lessonv2_'.$uniacid.date('Y-m-d'));
		}else{
			$images = "images/{$uniacid}/".date('Y', time())."/".date('m', time())."/".$images.$image_type;
			if (!empty($_W['setting']['remote']['type'])) {
				$remotestatus = file_remote_upload($images);
				if (is_error($remotestatus)) {
					exit(json_encode("远程附件上传失败，请联系管理员检查配置"));
					logging_run('课程'.$serial.'封面图导入失败，原因：远程附件上传失败', 'trace', 'fy_lessonv2_'.$uniacid.date('Y-m-d'));
				}
			}
		}
	}	

	if($v[7]){
		$vipview = explode('/', $v[7]);
		$vipview = array_filter($vipview);
		if(!empty($vipview)){
			$vipview = json_encode(array_values($vipview));
		}else{
			$vipview = '';
		}
	}

	if($v[18]){
		$recids =  explode('/', $v[18]);
		foreach($recids as $item){
			$tmprecid .= $item.',';
		}
		$recommendid = trim($tmprecid, ",");
		unset($recids);
		unset($tmprecid);
	}

	$commission = array(
		'commission_type' => intval($v[21]),
		'commission1'	  => floatval($v[22]),
		'commission2'	  => floatval($v[23]),
		'commission3'	  => floatval($v[24]),
	);

	if($v[27]){
		$appoint_info = explode('/', $v[27]);
		$appoint_info = array_filter($appoint_info);
		if(!empty($appoint_info)){
			$appoint_info = json_encode(array_values($appoint_info));
		}else{
			$appoint_info = '';
		}
	}

	if($v[28] || $v[29]){
		$buynow_info = array(
			'appoint_addres'   => $v[28],
			'appoint_validity' => $v[29],
		);
		$buynow_info= json_encode($buynow_info);
	}
	
	if($v[30]){
		$saler_uids = explode('/', $v[30]);
		$saler_uids = array_filter($saler_uids);
		if(!empty($saler_uids)){
			$saler_uids = json_encode(array_values($saler_uids));
		}else{
			$saler_uids = '';
		}
	}

	if($v[12]){
		$price_info = explode('/', $v[12]);
	}

	$newData = array(
		'uniacid'			=> $uniacid,
		'lesson_type'		=> $v[0],
		'bookname'			=> trim($v[1]),
		'pid'				=> $category[0],
		'cid'				=> $category[1],
		'teacherid'			=> $v[3],
		'images'			=> $images,
		'status'			=> $v[5],
		'teacher_income'	=> $v[6],
		'vipview'			=> $vipview,
		'lesson_show'		=> $v[8],
		'drag_play'			=> $v[9],
		'section_status'	=> $v[10],
		'displayorder'		=> $v[11],
		'descript'			=> $v[13],
		'price'				=> $price_info[1],
		'stock'				=> $price_info[2],
		'integral'			=> $v[14],
		'integral_rate'		=> $v[15],
		'deduct_integral'	=> $v[16],
		'virtual_buynum'	=> $v[17],
		'recommendid'		=> $recommendid,
		'support_coupon'	=> $v[19],
		'ico_name'			=> $v[20],
		'commission'		=> serialize($commission),
		'appoint_dir'		=> $v[25],
		'verify_number'		=> $v[26],
		'appoint_info'		=> $appoint_info,
		'buynow_info'		=> $buynow_info,
		'saler_uids'		=> $saler_uids,
		'addtime'			=> time(),
		'update_time'		=> time(),
	);
	$res = pdo_insert($this->table_lesson_parent, $newData);
	$lessonid = pdo_insertid();
	if($lessonid){
		if(intval($price_info[0])){
			$spec_data = array(
				'uniacid'    => $uniacid,
				'lessonid'   => $lessonid,
				'spec_day'	 => $price_info[0],
				'spec_price' => $price_info[1],
				'spec_stock' => $price_info[2],
				'spec_name'  => $price_info[3],
				'addtime'    => time(),
			);
			pdo_insert($this->table_lesson_spec, $spec_data);
		}
		$i++;
	}else{
		logging_run('课程'.$serial.'导入失败，原因：写入数据库失败', 'trace', 'fy_lessonv2_'.$uniacid.date('Y-m-d'));
	}

	unset($category);
	unset($images);
	unset($vipview);
	unset($recommendid);
	unset($appoint_info);
	unset($buynow_info);
	unset($saler_uids);
	unset($spec_data);
	unset($price_info);
}

message("成功导入{$i}个课程", $this->createWebUrl("lesson"), "success");