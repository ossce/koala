<?php
/**
 * 生成直播打赏订单
 * ============================================================================
 * 版权所有 2015-2020 风影科技，并保留所有权利。
 * 网站地址: https://www.fylesson.com
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件，未购买授权用户无论是否用于商业行为都是侵权行为！
 * 允许已购买用户对程序代码进行修改并在授权域名下使用，但是不允许对程序代码以
 * 任何形式任何目的进行二次发售，作者将依法保留追究法律责任的权力和最终解释权。
 * ============================================================================
 */

if(!$_W['isajax']){
	$this->resultJson('Illegal Request');
}

$uid = $_W['member']['uid'];
$ordersn = 'A' . date('Ymd').substr(time(), -5) . substr(microtime(), 2, 5) . sprintf('%02d', rand(1000, 9999));
$amount = $_GPC['amount'];

if(!is_numeric($amount)){
	$json_data = array(
		'code'		=> -1,
		'message'	=> "打赏金额必须为数字",
	);
	$this->resultJson($json_data);
}
if($amount <= 0){
	$json_data = array(
		'code'		=> -1,
		'message'	=> "打赏金额有误，请重新输入",
	);
	$this->resultJson($json_data);
}

$lessonid = intval($_GPC['lessonid']);
$lesson = pdo_fetch("SELECT a.bookname,a.teacherid,a.teacher_income,a.award_income,b.uid AS teacher_uid FROM " .tablename($this->table_lesson_parent). " a LEFT JOIN " .tablename($this->table_teacher). " b ON a.teacherid=b.id WHERE a.uniacid=:uniacid AND a.id=:id", array(':uniacid'=>$uniacid,':id'=>$lessonid));

if(empty($lesson)){
	$json_data = array(
		'code'		=> -1,
		'message'	=> "获取课程数据失败，请刷新后重试",
	);
	$this->resultJson($json_data);
}

$amount = intval(abs($amount));
$data = array(
	'uniacid'		 => $uniacid,
	'uid'			 => $uid,
	'ordersn'		 => $ordersn,
	'price'			 => $amount,
	'lessonid'		 => $lessonid,
	'bookname'		 => $lesson['bookname'],
	'teacherid'		 => $lesson['teacherid'],
	'teacher_income' => $lesson['award_income'] ? $lesson['award_income'] : $lesson['teacher_income'],
	'addtime'		 => time(),
);

if($lesson['teacher_uid']){
	$data['teacher_amount'] = round($data['price']*$data['teacher_income']*0.01, 2);
}

$res = pdo_insert($this->table_live_award, $data);
$orderid = pdo_insertid();

if($res){
	$json_data = array(
		'code'		=> 0,
		'message'	=> "请求接口成功",
		'goUrl'		=> $this->createMobileUrl('pay', array('orderid'=>$orderid,'ordertype'=>'liveaward')),
	);
	$this->resultJson($json_data);
}else{
	$json_data = array(
		'code'		=> -1,
		'message'	=> "网络繁忙，请稍后重试",
	);
	$this->resultJson($json_data);
}