<?php

$site_common->downloadFile($_GPC['fileid']);