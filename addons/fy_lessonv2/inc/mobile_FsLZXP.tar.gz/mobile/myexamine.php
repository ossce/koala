<?php
/**
 * 我的考试
 * ============================================================================
 * 版权所有 2015-2020 风影科技，并保留所有权利。
 * 网站地址: https://www.fylesson.com
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件，未购买授权用户无论是否用于商业行为都是侵权行为！
 * 允许已购买用户对程序代码进行修改并在授权域名下使用，但是不允许对程序代码以
 * 任何形式任何目的进行二次发售，作者将依法保留追究法律责任的权力和最终解释权。
 * ============================================================================
 */

checkauth();
$uid = $_W['member']['uid'];


$title = "我的考试";

$pindex =max(1,$_GPC['page']);
$psize = 10;

$condition = " a.uniacid=:uniacid AND a.uid=:uid";
$params[':uniacid'] = $uniacid;
$params[':uid'] = $uid;

if($_GPC['finished'] != ''){
	$condition .= " AND a.finished=:finished ";
	$params[':finished'] = $_GPC['finished'];
}

if($_W['isajax']){
	$list = pdo_fetchall("SELECT a.id,a.examine_id,a.submit_time,a.finished,a.corrected,a.score,b.title,b.cert_info,b.lesson_ids FROM " .tablename($this->table_exam_examine_record). " a LEFT JOIN " .tablename($this->table_exam_examine). " b ON a.examine_id=b.id WHERE {$condition} ORDER BY a.id DESC  LIMIT " . ($pindex-1) * $psize . ',' . $psize, $params);
	foreach($list as $k=>$v){
		if(!$v['finished']){
			$v['status_name'] = '未交卷';
		}else{
			if($v['corrected']){
				$v['status_name'] = '已批阅';
			}else{
				$v['status_name'] = '未批阅';
			}
		}

		$cert_info = json_decode($v['cert_info'], true);
		if($v['corrected'] && $cert_info['switch'] && $v['score'] >= $cert_info['score']){
			$v['cert'] = 1;
		}else{
			$v['cert'] = 0;
		}

		$lesson_ids = json_decode($v['lesson_ids'], true);
		if(!empty($lesson_ids)){
			foreach($lesson_ids as $item){
				$lesson = pdo_get($this->table_lesson_parent, array('uniacid'=>$uniacid,'id'=>$item), array('bookname'));
				$v['lesson'] .= $lesson['bookname']."；";
			}
			$v['lesson'] = "关联课程：".$v['lesson'];
		}else{
			$v['lesson'] = "暂未关联课程";
		}

		$list[$k] = $v;
	}

	$this->resultJson($list);
}else{
	$total = pdo_fetchcolumn("SELECT COUNT(*) FROM " .tablename($this->table_exam_examine_record). " a LEFT JOIN " .tablename($this->table_exam_examine). " b ON a.examine_id=b.id WHERE {$condition} ", $params);
}



include $this->template("../mobile/{$template}/myexamine");


?>